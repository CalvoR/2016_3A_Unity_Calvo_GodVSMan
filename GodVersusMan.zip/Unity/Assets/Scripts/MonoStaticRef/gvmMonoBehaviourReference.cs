﻿public static class gvmMonoBehaviourReference {
    public static gvmGodRessourcesManager Ressources { get; set; }
}