﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;


public class gvmSpellButton : NetworkBehaviour {

    public GameObject spellGO;
    public Text spellName;
    public gvmSpellData spellData;
}
